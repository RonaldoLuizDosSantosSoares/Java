package aula_1_Instancia_atributos_metodos;

public class Caminho_Fatec {

	String transporte1;
	String transporte2;
	String cor;
	String preco1;
	String preco2;
	
	public void Retorna_transporte_1 (String t1)
	{
		System.out.println("Transporte 1:\t" + t1);
	}
	
	public void Retorna_transporte_2 (String t2)
	{
		System.out.println("Transporte 2:\t" + t2);
	}
	
	public void Preco_passagem_1(String p1)
	{
		System.out.println("Preco do onibus:\t" + p1);
	}
	
	public void Preco_passagem_2 (String p2)
	{
		System.out.println("Preco do onibus 2:\t" + p2);
	}
	
}
