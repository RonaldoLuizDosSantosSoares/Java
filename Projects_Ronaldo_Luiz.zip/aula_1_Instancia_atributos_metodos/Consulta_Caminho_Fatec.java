package aula_1_Instancia_atributos_metodos;

public class Consulta_Caminho_Fatec {

	public static void main (String[] args)
    
    {
		Caminho_Fatec t = new Caminho_Fatec();
		t.Retorna_transporte_1("Buzão\t");
		t.Retorna_transporte_2("Buzão Azulzão\t");
		t.Preco_passagem_1("4.50\t");
		t.Preco_passagem_2("5,90\t");
		
	}
	
}
