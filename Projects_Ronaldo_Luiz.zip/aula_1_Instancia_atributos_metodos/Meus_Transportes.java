package aula_1_Instancia_atributos_metodos;

public class Meus_Transportes {

	String transporte1;
	String marca1;
	String modelo1;
	String cor1;
	String transporte2;
	String marca2;
	String modelo2;
	String cor2;
	double preco;
	String transporte3;
	
	public void Informa_Transportes() {
	
	System.out.println("TRANSPORTE: " + transporte1);
	System.out.println("MARCA: " + marca1);
	System.out.println("MODELO: " + modelo1);
	System.out.println("COR: " + cor1);
	System.out.println("TRANSPORTE: " + transporte2);
	System.out.println("MARCA: " + marca2);
	System.out.println("MODELO: " + modelo2);
	System.out.println("COR: " + cor2);
	System.out.println("PREÇO: " + preco);
	System.out.println("TRANSPORTE: " + transporte3);
	}
	
}
