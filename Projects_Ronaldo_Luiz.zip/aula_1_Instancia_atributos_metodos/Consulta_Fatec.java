package aula_1_Instancia_atributos_metodos;

public class Consulta_Fatec {

	        //instance variable
		    public static void main (String[] args)
		    
	    {
			Fatec f = new Fatec();
			f.Retorna_unidade("Baixada Santista\t");
			f.Retorna_curso("Análise e Desenvolvimento de Sistemas - Matutino\t");
			
		}
	
}
