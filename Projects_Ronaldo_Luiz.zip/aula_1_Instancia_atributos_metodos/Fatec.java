package aula_1_Instancia_atributos_metodos;

public class Fatec {

	    //attributes
		String unidade;
		String curso;
		
		//methods
		public void Retorna_unidade(String u)
		{
		System.out.println ("Unidade da Fatec:\t" + u);
		}
		
		public void Retorna_curso(String c)
		{
		System.out.println ("Curso da Fatec:\t" + c);
		}
	
}
