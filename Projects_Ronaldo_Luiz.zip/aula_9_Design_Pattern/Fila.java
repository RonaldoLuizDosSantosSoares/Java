package aula_9_Design_Pattern;

public class Fila {
/*
	// private static FILA fila;
	
	public void ImprimeDocumento() {}
	
	public void RemoveDocumento() {}
	
	public void RemoveTodosDocumentos() {}
	
	private FILA () {}
	
	private static FILA getInstance() {
		
	}
	
	if(fila == null)
	
	{
	fila = new FILA();
	}
	
	
	return fila
	*/
}
