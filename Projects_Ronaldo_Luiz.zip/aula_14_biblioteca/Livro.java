package aula_14_biblioteca;

public class Livro {

private String nome;
    
    public void setnome(String nome){
        this.nome = nome;
    }
    
    public String getnome(){
        return nome;
    }
	
	
}
