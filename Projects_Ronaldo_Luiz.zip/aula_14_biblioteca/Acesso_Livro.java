package aula_14_biblioteca;

public class Acesso_Livro extends Tipo_Romance {

    private String livraria;
    
    public void setlivraria(String livraria){
        this.livraria = livraria;
    }
    
    public String getlivraria(){
        return livraria;
    }


}
