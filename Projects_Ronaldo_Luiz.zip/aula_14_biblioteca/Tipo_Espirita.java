package aula_14_biblioteca;

public class Tipo_Espirita extends Livro {

	 private String Xavier;
	 private String preco;
	    
	    public void setXavier(String Xavier){
	        this.Xavier = Xavier;
	    }
	    
	    public String getXavier(){
	        return Xavier;
	    }
	    
	    public void setpreco(String preco){
	        this.preco = preco;
	    }
	    
	    public String getpreco(){
	        return preco;
	    }
	
}
