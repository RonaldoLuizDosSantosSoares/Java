package aula_14_biblioteca;

public class Tipo_Romance extends Livro {

	 private String drama;
	 private String preco1;
	    
	    public void setdrama(String drama){
	        this.drama = drama;
	    }
	    
	    public String getdrama(){
	        return drama;
	    }
	
	    public void setpreco1(String preco1){
	        this.preco1 = preco1;
	    }
	    
	    public String getpreco1(){
	        return preco1;
	    }
	    
}
