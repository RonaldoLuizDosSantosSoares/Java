package aula_14_biblioteca;

import javax.swing.JOptionPane;

public class Bib {

public static void main(String[] args) {
    	
    	Tipo_Espirita espirita = new Tipo_Espirita();
    	Acesso_Livro dispo = new Acesso_Livro();
    	
    	String u,v,w,t,z;
		int x;
		
		z = JOptionPane.showInputDialog ("Digite 1 para um livro da categoria espirita ou 2 para categoria Romance ");
		
x = Integer.parseInt( z );
		
		if (z.length()==1) {
			switch(x) {
			case 1: {
				u = JOptionPane.showInputDialog ("Escrever o nome do livro: ");
				v = JOptionPane.showInputDialog ("Escrever o ano que foi lançado:  ");
				t = JOptionPane.showInputDialog ("Digitar o preço: ");
				
				espirita.setnome(u);
				espirita.setXavier(v);
				espirita.setpreco(t);
				System.out.println("Nome: "+espirita.getnome());
				System.out.println("Ano: "+espirita.getXavier());
				System.out.println("Preço: "+espirita.getpreco());

				break;
			}
			
			case 2: {
				u = JOptionPane.showInputDialog ("Escrever o nome do livro: ");
				v = JOptionPane.showInputDialog ("Escrever o ano que foi lançado: ");
				t = JOptionPane.showInputDialog ("Digitar o preço: ");
				w = JOptionPane.showInputDialog ("Digitar a livraria: ");
				
				dispo.setnome(u);
				dispo.setdrama(t);
				dispo.setpreco1(v);
				dispo.setlivraria(w);
				System.out.println("Nome: "+dispo.getnome());
				System.out.println("Ano: "+dispo.getdrama());
				System.out.println("Preco: "+dispo.getpreco1());
				System.out.println("Local: "+dispo.getlivraria());
				break;
			}
			
			}//switch
			
		}//if
		
    }
	
}
