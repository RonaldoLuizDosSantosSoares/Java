package aula_6_Metodo_construtor;

public class Revendedora1 {
	
	public static void main (String args[]) {
		
	Automovel A = new Automovel();
	A.mostracarro();
	
	Automovel B = new Automovel(1999, "Volkswagem", "Fusca", 9999.99);
	B.mostracarro();
	}
	
}
