package encapsulamento_2;

import encapsulamento_1.Acesso_Numeros;
// importar + pacote + classe

public class Verifica_Encapsulamento_2 {
public static void main (String args[]) {
	
	Acesso_Numeros chave = new Acesso_Numeros();
	
	/*chave.a = 10; ENCAPSULAMENTO PACKAGE PRIVATE
	 * Não permite acesso de fora do pacote
	 */
	chave.setNumero("a", 10);
	
	chave.b = 20;
	
	//chave.c = 30; NÃO É POSSIVEL ACESSAR VARIAVEL PRIVATE DIRETAMENTE
	chave.setNumero("c",30);
	
	//chave.d = 40; NÃO É POSSIVEL ACESSAR VARIAVEL PROTECTED DIRETAMENTE FORA DO PACOTE
	chave.setNumero("d", 40);
	
	chave.mostra_numero();
}
	
}
