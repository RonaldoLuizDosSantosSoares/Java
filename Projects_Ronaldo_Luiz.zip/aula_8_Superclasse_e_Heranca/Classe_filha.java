package aula_8_Superclasse_e_Heranca;

public class Classe_filha extends Superclasse {

	private String atributo_2;
	
	Classe_filha (){
		super();
		
		System.out.println("acesso ao método construtor da Classe_filha_1");
		
	}
	
	public void set_atributo_2(String atributo_2) {
		this.atributo_2 = atributo_2;
	}
	
	public String get_atributo_2() {
		return atributo_2;
	}
	
}
