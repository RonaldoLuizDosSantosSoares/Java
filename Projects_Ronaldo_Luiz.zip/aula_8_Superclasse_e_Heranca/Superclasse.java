package aula_8_Superclasse_e_Heranca;

public class Superclasse {

	private String atributo_1;
	
	Superclasse(){
		System.out.println("acesso ao método construtor da superclasse");
	}
	
	public void set_atributo_1 (String atributo_1) {
		this.atributo_1 = atributo_1;
	
	}
	
	public String get_atributo_1 () {
		return atributo_1;
	}
	
}
