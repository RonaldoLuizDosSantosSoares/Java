package aula_8_Superclasse_e_Heranca;

public class Classe_filha_2 extends Classe_filha {

	Classe_filha_2 (){
		super();
	}
	
}
