package aula_8_Superclasse_e_Heranca;

public class Classe_filha_3 extends Classe_filha {

	private String atributo_3;
	
	Classe_filha_3(){
		super();
		
		System.out.println("acesso ao método construtor da Classe_filha_3");
	}
	
	public void set_atributo_3(String atributo_3) {
		this.atributo_3 = atributo_3;
	}
	
	public String get_atributo_3() {
		return atributo_3;
	}
	
}
