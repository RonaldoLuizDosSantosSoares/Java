package aula_5_Instancia;

public class Dispositivel_Movel {
	
	public String numero;
	
	public static String usuario;
	public static int DDD;
	
	public void identifica_numero(String numero) {
		this.numero = numero;
	}
	
	public void identifica_usuario(String usuario) {
		this.usuario = usuario;
	}
}
