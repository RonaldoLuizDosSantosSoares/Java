package aula_13_PJ;

import javax.swing.JOptionPane;

public class UsaFuncionario {

	public static void main (String args[]) {
		//OBJETOS
		Funcionario funcionario = new Funcionario();
		PessoaJuridica func = new PessoaJuridica();
		
		String u,v,t,z;
		int x;
		
		z = JOptionPane.showInputDialog ("Digite 1 se contribuinte é pessoa fisica");
		
		//CONVERSÃO DE STRING PARA FLUTUANTE
		
		x = Integer.parseInt( z );
		
		if (z.length()==1) {
			switch(x) {
			case 1: {
				u = JOptionPane.showInputDialog ("Escrever o nome do contribuinte: ");
				v = JOptionPane.showInputDialog ("Escrever o RG do contribuinte: ");
				t = JOptionPane.showInputDialog ("Escrever a identificação do cartão do contribuinte: ");
				
				funcionario.setnome(u);
				funcionario.setrg(v);
				funcionario.setcartao(t);
				System.out.println("Nome: "+funcionario.getnome());
				System.out.println("RG: "+funcionario.getrg());
				System.out.println("Cartão: "+funcionario.getcartao());
				break;
			}
			
			case 2: {
				u = JOptionPane.showInputDialog ("Escrever o nome do contribuinte: ");
				v = JOptionPane.showInputDialog ("Escrever o cnpj do contribuinte: ");
				t = JOptionPane.showInputDialog ("Escrever a identificação do cartão do contribuinte: ");
				
				funcionario.setnome(u);
				func.setcnpj(v);
				funcionario.setcartao(t);
				System.out.println("Nome: "+funcionario.getnome());
				System.out.println("CNPJ: "+func.getcnpj());
				System.out.println("Cartão: "+funcionario.getcartao());
				break;
			}
			
			}//switch
			
		}//if
				
	}//void main
}
