package aula_13_PJ;

public class PessoaFisica extends Contribuinte {

	private String rg;
	
	public void setrg (String rg) {
		this.rg = rg;
	}
	
	public String getrg(){
        return rg;
    }
	
}
