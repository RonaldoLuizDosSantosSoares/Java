package aula_13_PJ;

public class PessoaJuridica extends Contribuinte {

	private String cnpj;
	
	public void setcnpj(String cnpj) {
		this.cnpj = cnpj;
	}
	
	public String getcnpj() {
		return cnpj;
	}
	
}
