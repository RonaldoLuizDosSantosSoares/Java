package aula_13_PJ;

public class Contribuinte {

	private String nome;
	
	public void setnome(String nome) {
        this.nome = nome;
    }

    public String getnome(){
        return nome;
    }
	
}
