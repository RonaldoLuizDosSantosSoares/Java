package aula_13_PJ;

public class Funcionario extends PessoaFisica {
	
	private String cartao;
	
	public void setcartao(String cartao) {
		this.cartao = cartao;
	}

	public String getcartao() {
		return cartao;
	}
	
}
