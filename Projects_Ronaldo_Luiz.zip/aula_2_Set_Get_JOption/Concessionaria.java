package aula_2_Set_Get_JOption;

import javax.swing.JOptionPane;

public class Concessionaria {

public static void main (String args[]) {
		
		Automovel e = new Automovel();
		
		String mr, md, pr, cr;
		double pc;
		
		mr = JOptionPane.showInputDialog("Digite a Marca: ");
		md = JOptionPane.showInputDialog("Digite a Modelo: ");
		cr = JOptionPane.showInputDialog("Digite a Cor: ");
		pr = JOptionPane.showInputDialog("Digite a Preço: ");
		
		pc = Double.parseDouble(pr);
		
		e.setMarca(mr);
		e.setModelo(md);
		e.setCOR(cr);
		e.setPRECO(pc);
		
		JOptionPane.showMessageDialog(null, "DADOS DO CARRO \n" +
				" MARCA: " + e.getMarca() +
				"\n MODELO: " + e.getModelo() +
				"\n COR: " + e.getCOR() +
				"\n PREÇO: " + e.getPRECO() , "", JOptionPane.PLAIN_MESSAGE);
	
	}
	
}
