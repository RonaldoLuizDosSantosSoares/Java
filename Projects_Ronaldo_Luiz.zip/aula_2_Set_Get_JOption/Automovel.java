package aula_2_Set_Get_JOption;

public class Automovel {
	
	private String marca;
	private String modelo;
	private String cor;
	private double preco;
		
		public void setMarca(String marca) {
			this.marca = marca;
		}
		
		public void setModelo(String modelo) {
			this.modelo = modelo;
		}
		
		public void setCOR(String cor) {
			this.cor = cor;
		}
		
		public void setPRECO(Double preco) {
			this.preco = preco;
		}
		
		public String getMarca() {
			return marca;
		}
		
		public String getModelo() {
			return modelo;
		}
		
		public String getCOR() {
			return cor;
		}
		
		public double getPRECO() {
			return preco;
		}
		
	}


