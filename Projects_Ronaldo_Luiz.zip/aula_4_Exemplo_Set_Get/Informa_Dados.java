package aula_4_Exemplo_Set_Get;

import javax.swing.JOptionPane;

public class Informa_Dados {

	public static void main (String [] args ) {
		Dados_Contribuinte a = new Dados_Contribuinte();

		String w, x, y, z;
		
		w = JOptionPane.showInputDialog("Digite o nome: ");
		x = JOptionPane.showInputDialog("Digite a cpf: ");
		y = JOptionPane.showInputDialog("Digite a cnpj: ");
		z = JOptionPane.showInputDialog("Digite a cartao: ");
		
		a.setNome (w);
		a.setCPF (x);
		a.setCNPJ (y);
		a.setCartao (z);
		
		JOptionPane.showMessageDialog(null, "DADOS DO CLIENTE \n" +
				" NOME: " + a.getNome() +
				"\n CPF: " + a.getCPF() +
				"\n CNPJ: " + a.getCNPJ() +
				"\n CARTÃO: " + a.getCartao() , "", JOptionPane.PLAIN_MESSAGE);
		
		/*
		System.out.println("NOME: \t"+ a.getNome());
		System.out.println("CPF: \t"+ a.getCPF());
		System.out.println("CNPJ: \t"+ a.getCNPJ());
		System.out.println("CARTÃO: \t"+ a.getCartao());
		*/
	}
	
}
