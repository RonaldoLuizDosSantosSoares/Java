package p1_davi;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class Mainpanel extends Main implements ActionListener{
	
	 private JLabel label;

	 private JButton botao;
	 
	 public Mainpanel()  {
		    //Instancia um novo label e um novo botão
		    label = new JLabel("Aperte aqui ->");
		    botao = new JButton("Botão");
		    
		    //seta os limites do labbel e do botão
		    this.label.setBounds(100,100,100,20);
		    this.botao.setBounds(200,100,100,20);

		    //Adiciona o label e o botão a este Panel
		    this.add(this.label);
		    this.add(this.botao);

	//adiciona ao um botão um "escutador", responsável por tratar seus cliques.
	    this.botao.addActionListener(this);
	  }

	  /**
	   * Método que trata quando uma ação é executada 
	   */
	  public void actionPerformed(ActionEvent e)  {
	    //Verifica se o objeto onde a ação foi executa é o botão desejado.
	    if(e.getSource()==this.botao){
	      JOptionPane.showMessageDialog(null,"Você apertou no Botão!");
	    }
	  }
}
