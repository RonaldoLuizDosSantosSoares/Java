package p1_davi;

import javax.swing.*;
import java.awt.event.*;

public class Main extends JFrame {

	public Main() {

	    this.setTitle("Minha primeira Tela!");

	    this.setSize(800, 600);
	
	    addWindowListener(new WindowAdapter() {
	        public void windowClosing(WindowEvent e) {
	          System.exit(0);
	         
	        }
	    });
	        
	        Main panel = new Main(); 
	        
	        //adicona o JPanel a este JFrame
	        this.getContentPane().add( panel ); 
	        
	        //manda mostrar o JFrame
	        this.show(); 
	}
	
	public static void main(String args[])  {
	    new Main();
	  }
	
	

}