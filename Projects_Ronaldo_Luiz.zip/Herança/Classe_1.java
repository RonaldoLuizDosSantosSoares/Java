package Herança;

public class Classe_1 extends Classe_0 {

	
	
}
