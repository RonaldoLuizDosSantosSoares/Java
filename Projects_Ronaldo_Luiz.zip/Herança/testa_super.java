package Herança;

public class testa_super {

	public static void main(String args[]) {
		Classe_1 a = new Classe_1();
		Classe_2 b = new Classe_2();
		Classe_3 c = new Classe_3();
	}
	
}
