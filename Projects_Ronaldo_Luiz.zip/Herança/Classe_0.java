package Herança;

public class Classe_0 {
	
	Classe_0 () {
		System.out.println("método construtor da superclasse");
	}

}
