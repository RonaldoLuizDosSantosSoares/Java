package Herança;

public class Classe_3 extends Classe_2 {

}
