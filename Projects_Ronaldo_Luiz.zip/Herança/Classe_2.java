package Herança;

public class Classe_2 extends Classe_1 {

}
