package aula_3_Instance_var;

import javax.swing.JOptionPane;

	public class Livraria {
		
		//atributos
		String editora;
		String autor;
		String livro;
		String ano_publi;
		int quantidade;
		double preco;
		
		
		//metodos
		public void Informa_Livros(int codigo) {
			
			switch(codigo) {
			
			case 1: JOptionPane.showMessageDialog(null, "CATEGORIA ROMANCE \n" +
					" LIVRO: " + livro +
					"\n EDITORA: " + editora +
					"\n AUTOR: " + autor +
					"\n ANO DE PUBLICAÇÃO: " + ano_publi +
					"\n QUANTIDADE: " + quantidade +
					"\n PREÇO R$: " + preco, "", JOptionPane.PLAIN_MESSAGE); break;
					
			case 2: JOptionPane.showMessageDialog(null, "CATEGORIA ESPÍRITA \n" +
					"LIVRO: " + livro +
					"\n EDITORA: " + editora +
					"\n AUTOR: " + autor +
					"\n ANO DE PUBLICAÇÃO: " + ano_publi +
					"\n QUANTIDADE: " + quantidade +
					"\n PREÇO R$: " + preco, "", JOptionPane.PLAIN_MESSAGE); break;
					
			case 3: JOptionPane.showMessageDialog(null, "CATEGORIA INFORMÁTCA \n" +
					"LIVRO: " + livro +
					"\n EDITORA: " + editora +
					"\n AUTOR: " + autor +
					"\n ANO DE PUBLICAÇÃO: " + ano_publi +
					"\n QUANTIDADE: " + quantidade +
					"\n PREÇO R$: " + preco, "", JOptionPane.PLAIN_MESSAGE); break;
					
			default: System.out.println("Código não corresponde a nenhuma categoria de livro");
			}
		}
	
}
