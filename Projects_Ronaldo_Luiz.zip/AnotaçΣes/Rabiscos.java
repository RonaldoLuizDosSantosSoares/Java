package Anotações;

public class Rabiscos {

	//1: O que é superclasse? A herança é um princípio da POO que permite a criação de novas classes a partir de outras previamente criadas. Essas novas classes são chamadas de subclasses, ou classes derivadas; e as classes já existentes, que deram origem às subclasses, são chamadas de superclasses, ou classes base.
	
	//2: O que é subclasse? Uma subclasse é uma forma especializada da superclasse que herda seus atributos
	
	//3: Não se usa muito superclasse e hereança no ambito profissional
	
	//4: Quais os tipos de encapsulamento modificador? os tipos são: é dividido em dois níveis: Nível de classe: Quando determinamos o acesso de uma classe inteira que pode ser public ou Package-Private (padrão); Nível de membro: Quando determinamos o acesso de atributos ou métodos de uma classe que podem ser public, private, protected ou Package-Private (padrão).
	
	//5: Existem diversos tipos de qualificador, entre os quais serão citados no momento public e private. O qualificador public indica que o conteúdo da classe pode ser usado livremente por outras classes do mesmo pacote ou de outro pacote, isto é, a classe será visível a todas as classes, estejam elas no mesmo pacote ou não.

    //6: O this referencia a classe atual onde ele está sendo chamado no Java. Max a palavra this, serve para referenciar os atributos que sempre vão existir, por exemplo.

	//7: Os pacotes são usados para agrupar classes relacionadas. Desta forma, conseguimos evitar conflitos de nomes entre classes, e também escrever código mais fácil de manter e atualizar. Além disso, os pacotes facilitam a busca ou pesquisa de classes, interfaces e enumerações.
	
	//8: O que é UML em Java? UML é uma linguagem padrão da OMG para • visualização, • especificação, • construção e • documentação de software orientado a objetos. A existência de um modelo visual facilita a comunicação e faz com que os membros de um grupo tenham a mesma idéia do sistema.
	
	//9: As 3 representações da UML: O nome da classe, seus atributos e por fim os métodos.
	
	
}
