package aula_10_Heranca_CEETPS;

public class Centro_Paula_Souza {

    private String Fatec;
    private String cidade;

    // metodo construtor
    public Centro_Paula_Souza(String cidade) {
        this.cidade = cidade;
        System.out.println("método construtor da superclasse: " + "cidade: " + cidade);
    }

    public void setFatec(String Fatec) {
        this.Fatec = Fatec;
    }

    public String getFatec(){
        return Fatec;
    }

}
