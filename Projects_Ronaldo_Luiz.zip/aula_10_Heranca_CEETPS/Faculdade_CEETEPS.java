package aula_10_Heranca_CEETPS;

public class Faculdade_CEETEPS extends Centro_Paula_Souza {

    private String faculdade;
    private String estado;

    public Faculdade_CEETEPS(){
        super("Santos");

    }

    public void setFaculdade(String faculdade) {
        this.faculdade = faculdade;
    }

    public String getFaculdade(){
        return faculdade;
    }

    
    public void setestado(String estado) {
        this.estado = estado;
    }

    public String getestado(){
        return estado;
    }

}
