package aula_10_Heranca_CEETPS;

public class Disciplinas_CEETEPS extends Faculdade_CEETEPS {

	private String nome_disciplina;
	
	public void setDisciplina (String nome_disciplina) {
		this.nome_disciplina = nome_disciplina;
	}
	
	public String getDisciplina() {
		return nome_disciplina;
	}
	
}
