package aula_10_Heranca_CEETPS;

public class Acessa_Faculdade {

    public static void main(String args[]) {
        Faculdade_CEETEPS ceetps = new Faculdade_CEETEPS();
        Disciplinas_CEETEPS disciplinas = new Disciplinas_CEETEPS();
        
        
        
        ceetps.setFatec("Fatec Baixada Santista");
        System.out.println("Fatec \t" + ceetps.getFatec());

        ceetps.setFaculdade("Analise e desenvolvimento de sistemas");
        System.out.println("Faculdade \t" + ceetps.getFaculdade());
        
        ceetps.setestado("São Paulo");
        System.out.println("Estado \t" + ceetps.getestado());

        disciplinas.setDisciplina("Programação Orientada a Objetos");
        System.out.println("Disciplina \t" + disciplinas.getDisciplina());

        
        
    }

}
